<?php
include('connection.php'); 

echo "string";

$sql = "INSERT INTO message (name, email, comment)
    VALUES ('".$_POST["name"]."','".$_POST["email"]."','".$_POST["comment"]."')";
    // use exec() because no results are returned
$conn->exec($sql);

if ($conn) {
	$status = 1;
}else {
	$status = 0;
}

   

header('Location: contact.php');




?>
