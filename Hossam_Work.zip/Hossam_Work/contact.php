<?php
$Page = 'contact';
 include('header.php'); 
 ?>

		<header id="gtco-header" class="gtco-cover gtco-cover-xs gtco-inner" role="banner">
			<div class="gtco-container">
				<div class="row">
					<div class="col-md-12 col-md-offset-0 text-left">
						<div class="display-t">
							<div class="display-tc">
								<div class="row">
									<div class="col-md-8 animate-box">
										<h1 class="no-margin">Contact Us</h1>
										 <p>We are eager to serve you.</p> 
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</header>
		<!-- END #gtco-header -->

		

		<div class="gtco-section">
			<div class="gtco-container">
				<div class="row">
					<div class="col-md-8 col-md-offset-2 gtco-heading text-center">
						<h2>Get In Touch</h2>
						<p>Send us an E-Mail and we will get back to you right away </p>
					</div>
				</div>
				<div class="row">
					<div class="col-md-6">
						<form class="cmxform" id="commentForm" method="POST" action="sendMessege.php" enctype="multipart/form-data">
							<div class="form-group">
								<label for="name">Name</label>
								<input type="text" name="name" class="form-control" id="name">
							</div>
							<div class="form-group">
								<label for="name">Email</label>
								<input type="text" name="email" class="form-control" id="email">
							</div>
							<div class="form-group">
								<label for="message"></label>
								<textarea name="comment" id="message" cols="30" rows="10" class="form-control"></textarea>
							</div>
							<div class="form-group">
								<input type="submit" class="btn btn btn-special" class="submit" value="Submit">
							</div>
						</form>
						
					</div>
					<div class="col-md-5 col-md-push-1">
						<div class="gtco-contact-info">
							<h3>Our Address</h3>
							<!-- <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p> -->
							<ul >
								<li class="address">2 Sudan Street, Dokki, Giza Governorate</li>
								<li class="phone"><a href="tel://00201033834556">+20 1033834556</a></li>
								<li class="email"><a href="#">contact@midrule.com</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- END .gtco-services -->

		
		<!-- <div id="map"></div> -->
		<iframe
			src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3454.0350880503215!2d31.1975938!3d30.035851199999996!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x145846c903ff8757%3A0x7609e8fbbcc77174!2sWeraash.com!5e0!3m2!1sen!2seg!4v1520773842023"
			width="100%" height="550" frameborder="0" style="border:0" allowfullscreen></iframe>

<?php include('footer.php'); ?>