<footer id="gtco-footer" class="gtco-section" role="contentinfo">
				<div class="gtco-container">
					<div class="row row-pb-md">
						<div class="col-md-8 col-md-offset-2 gtco-cta text-center">
							<h3>We'd Love To Talk</h3>
							<p><a href="/contact.html" class="btn btn-white btn-outline">Contact Us</a></p>
						</div>
					</div>
					<div class="row row-pb-md">
						<div class="col-md-4 gtco-widget gtco-footer-paragraph">
							<h3>Mid Rule</h3>
							<p>Mid Rule is fairly new company looking to invade the market as the best web and applications development organization.</p>
						</div>
						<div class="col-md-4 gtco-footer-link">
							<div class="row">
								<div class="col-md-6">
									<ul class="gtco-list-link">
										<li><a href="/">Home</a></li>
										<!-- <li><a href="/portfolio.html">Portfolio</a></li> -->
										<li><a href="/about.html">About</a></li>
										<li><a href="/contact.html">Contact</a></li>
									</ul>
								</div>
								<div class="col-md-6">
									<p>
										<a href="tel://00201033834556">+20 1033834556</a> <br>
										<a href="#">contact@midrule.com</a>
									</p>
								</div>
							</div>
						</div>
						<div class="col-md-4 gtco-footer-subscribe">
							<form class="form-inline">
							  <div class="form-group">
								<label class="sr-only" for="exampleInputEmail3">Email address</label>
								<input type="email" class="form-control" id="" placeholder="Email">
							  </div>
							  <button type="submit" class="btn btn-primary">Send</button>
							</form>
						</div>
					</div>
				</div>
			</footer>	
	</div>

	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
	</div>
	
	<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- countTo -->
	<script src="js/jquery.countTo.js"></script>
	<!-- Carousel -->
	<script src="js/owl.carousel.min.js"></script>
	<!-- Magnific Popup -->
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/magnific-popup-options.js"></script>
	<script src="js/jquery.validate.min.js"></script>
	<!-- Main -->
	<script src="js/main.js"></script>
	

	</body>
</html>

<!--
	Cube by FreeHTML5.co
	Twitter: http://twitter.com/gettemplateco
	URL: http://freehtml5.co
-->